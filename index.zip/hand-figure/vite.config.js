import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  server: { host: true, port: 5199, strictPort: true },
  preview: { host: true, port: 5199, strictPort: true },
  build: { target: 'es2020', chunkSizeWarningLimit: 1200 },
});
