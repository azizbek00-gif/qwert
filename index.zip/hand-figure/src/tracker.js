import * as THREE from 'three';
import { OneEuro } from './filters.js';

export const HAND_CONNECTIONS = [
  [0, 1], [1, 2], [2, 3], [3, 4],
  [0, 5], [5, 6], [6, 7], [7, 8],
  [5, 9], [9, 10], [10, 11], [11, 12],
  [9, 13], [13, 14], [14, 15], [15, 16],
  [13, 17], [17, 18], [18, 19], [19, 20],
  [0, 17],
];

const clamp01 = (v) => Math.min(1, Math.max(0, v));
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);

// angle (degrees) at vertex b between segments b->a and b->c
function angleAt(b, a, c) {
  const ux = a.x - b.x, uy = a.y - b.y, uz = a.z - b.z;
  const vx = c.x - b.x, vy = c.y - b.y, vz = c.z - b.z;
  const d = ux * vx + uy * vy + uz * vz;
  const m = Math.hypot(ux, uy, uz) * Math.hypot(vx, vy, vz) || 1e-9;
  return (Math.acos(clamp(d / m, -1, 1)) * 180) / Math.PI;
}

const FINGER_CHAINS = [
  [5, 6, 7, 8], // index
  [9, 10, 11, 12], // middle
  [13, 14, 15, 16], // ring
  [17, 18, 19, 20], // pinky
];

// 0..1 "how extended is this finger" using 3D world landmarks -> independent of
// hand rotation, distance to the camera and of which hand it is.
function fingerScore(wl, chain) {
  const [mcp, pip, dip, tip] = chain.map((i) => wl[i]);
  const bend = (angleAt(wl[chain[1]], wl[chain[0]], wl[chain[2]]) + angleAt(wl[chain[2]], wl[chain[1]], wl[chain[3]])) / 2;
  const straight = clamp01((bend - 105) / (162 - 105));
  const reach = dist(tip, wl[0]) / Math.max(dist(mcp, wl[0]), 1e-4);
  const reachScore = clamp01((reach - 1.2) / (1.62 - 1.2));
  // fingertip must also be further from the wrist than the PIP joint
  const order = dist(tip, wl[0]) > dist(pip, wl[0]) * 1.02 && dist(dip, wl[0]) > dist(pip, wl[0]) ? 1 : 0.35;
  return (0.55 * straight + 0.45 * reachScore) * order;
}

function thumbScore(wl) {
  // Thumb folded over a fist or tucked against the palm stays close to the index knuckle /
  // PIP joints; a raised thumb is far from them. Distances are relative to palm length.
  const palm = Math.max(dist(wl[0], wl[9]), 1e-4);
  const away = clamp01((dist(wl[4], wl[5]) / palm - 0.55) / (0.9 - 0.55));
  const awayPip = clamp01((Math.min(dist(wl[4], wl[6]), dist(wl[4], wl[10])) / palm - 0.3) / (0.62 - 0.3));
  const straight = clamp01((angleAt(wl[3], wl[2], wl[4]) - 140) / (172 - 140));
  return 0.45 * away + 0.35 * awayPip + 0.2 * straight;
}

// bounding box of a hand's 2D landmarks
function handBox(lm) {
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  for (const p of lm) {
    if (p.x < x0) x0 = p.x;
    if (p.x > x1) x1 = p.x;
    if (p.y < y0) y0 = p.y;
    if (p.y > y1) y1 = p.y;
  }
  return { x0, y0, x1, y1, w: x1 - x0, h: y1 - y0, cx: (x0 + x1) / 2, cy: (y0 + y1) / 2 };
}

function boxIoU(a, b) {
  const iw = Math.min(a.x1, b.x1) - Math.max(a.x0, b.x0);
  const ih = Math.min(a.y1, b.y1) - Math.max(a.y0, b.y0);
  if (iw <= 0 || ih <= 0) return 0;
  const inter = iw * ih;
  return inter / (a.w * a.h + b.w * b.h - inter);
}

// MediaPipe sometimes reports ONE physical hand twice (two overlapping skeletons). Keep the more
// confident detection of every such pair, otherwise the "second hand" would fire on its own.
function dropDuplicateHands(hands) {
  for (const h of hands) h.box = handBox(h.lm);
  const out = [];
  const order = hands.slice().sort((a, b) => b.score - a.score);
  for (const h of order) {
    const dup = out.some((k) => {
      const size = Math.max(k.box.w, k.box.h, h.box.w, h.box.h);
      const cd = Math.hypot(k.box.cx - h.box.cx, k.box.cy - h.box.cy);
      return boxIoU(k.box, h.box) > 0.3 && cd < 0.5 * size;
    });
    if (!dup) out.push(h);
  }
  return out;
}

const V = {
  sub: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]],
  dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
  cross: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]],
  len: (a) => Math.hypot(a[0], a[1], a[2]),
  norm: (a) => {
    const l = Math.hypot(a[0], a[1], a[2]) || 1e-9;
    return [a[0] / l, a[1] / l, a[2] / l];
  },
};

// world landmark (MediaPipe: x right, y down, z away from camera, raw un-mirrored image)
// -> scene space (x right on the mirrored display, y up, z toward the viewer)
const toScene = (p) => [-p.x, -p.y, -p.z];

function handQuaternion(wl, out) {
  const p0 = toScene(wl[0]);
  const p5 = toScene(wl[5]);
  const p9 = toScene(wl[9]);
  const p17 = toScene(wl[17]);
  const y = V.norm(V.sub(p9, p0)); // wrist -> middle knuckle (fingers direction)
  let x = V.sub(p5, p17); // pinky -> index knuckle
  x = V.norm(V.sub(x, y.map((c) => c * V.dot(x, y))));
  const z = V.cross(x, y);
  const m = new THREE.Matrix4().makeBasis(
    new THREE.Vector3(...x),
    new THREE.Vector3(...y),
    new THREE.Vector3(...z),
  );
  return out.setFromRotationMatrix(m);
}

class Channel {
  constructor(kind) {
    this.kind = kind; // 'dom' | 'sec'
    this.resetFilters();
    this.present = false;
    this.lastSeen = -10;
    this.lm = null; // filtered normalized landmarks [{x,y,z}]
    this.wl = null; // filtered world landmarks
    this.wrist = [0.5, 0.5];
    this.anchor = [0.5, 0.5];
    this.quat = new THREE.Quaternion();
    this.hasQuat = false;
    this.fingerOn = [false, false, false, false, false];
    this.scores = [0, 0, 0, 0, 0];
    this.count = 0;
    this.candidate = -1;
    this.candidateFrames = 0;
    this.candidateSince = 0;
    this.pinchRatio = 0.5;
  }

  resetFilters() {
    this.fLm = Array.from({ length: 21 }, () => [new OneEuro(2.2, 7), new OneEuro(2.2, 7), new OneEuro(1.5, 3)]);
    this.fWl = Array.from({ length: 21 }, () => [new OneEuro(1.6, 9), new OneEuro(1.6, 9), new OneEuro(1.6, 9)]);
    this.fAnchor = [new OneEuro(2.0, 6), new OneEuro(2.0, 6)];
    this.fPinch = new OneEuro(1.8, 4);
    this.hasQuat = false;
  }

  update(hand, t) {
    const w = hand.lm[0];
    if (this.present && Math.hypot(w.x - this.wrist[0], w.y - this.wrist[1]) > 0.28 && t - this.lastSeen < 0.3) {
      // tracker identity jumped to a different hand -> don't smooth across the jump
      this.resetFilters();
    }
    this.lm = hand.lm.map((p, i) => ({
      x: this.fLm[i][0].filter(p.x, t),
      y: this.fLm[i][1].filter(p.y, t),
      z: this.fLm[i][2].filter(p.z, t),
    }));
    this.wl = hand.wl.map((p, i) => ({
      x: this.fWl[i][0].filter(p.x, t),
      y: this.fWl[i][1].filter(p.y, t),
      z: this.fWl[i][2].filter(p.z, t),
    }));
    this.wrist = [this.lm[0].x, this.lm[0].y];
    const ids = [0, 5, 9, 13, 17];
    const cx = ids.reduce((s, i) => s + this.lm[i].x, 0) / ids.length;
    const cy = ids.reduce((s, i) => s + this.lm[i].y, 0) / ids.length;
    this.anchor = [this.fAnchor[0].filter(cx, t), this.fAnchor[1].filter(cy, t)];
    handQuaternion(this.wl, (this._q = this._q || new THREE.Quaternion()));
    if (this.hasQuat && this._q.dot(this.quat) < 0) {
      this._q.set(-this._q.x, -this._q.y, -this._q.z, -this._q.w);
    }
    this.quat.copy(this._q);
    this.hasQuat = true;

    // ---- finger states with hysteresis ----
    const scores = [thumbScore(this.wl), ...FINGER_CHAINS.map((c) => fingerScore(this.wl, c))];
    this.scores = scores;
    for (let i = 0; i < 5; i++) {
      if (!this.fingerOn[i] && scores[i] > 0.62) this.fingerOn[i] = true;
      else if (this.fingerOn[i] && scores[i] < 0.42) this.fingerOn[i] = false;
    }
    const raw = this.fingerOn.filter(Boolean).length;
    if (raw === this.count) {
      this.candidate = -1;
      this.candidateFrames = 0;
    } else if (raw === this.candidate) {
      // a new finger count must hold for >= 2 frames AND >= 0.1 s (frame-rate independent)
      this.candidateFrames++;
      if (this.candidateFrames >= 2 && t - this.candidateSince >= 0.1) {
        this.count = raw;
        this.candidate = -1;
        this.candidateFrames = 0;
      }
    } else {
      this.candidate = raw;
      this.candidateFrames = 1;
      this.candidateSince = t;
    }

    // ---- thumb-index pinch (used by the second hand for scale) ----
    const palm = Math.max(dist(this.wl[0], this.wl[9]), 1e-4);
    const tipGap = dist(this.wl[4], this.wl[8]);
    this.pinchRatio = this.fPinch.filter(tipGap / palm, t);

    this.present = true;
    this.lastSeen = t;
  }
}

export class Tracker {
  constructor({ swapHands = false } = {}) {
    this.dom = new Channel('dom');
    this.sec = new Channel('sec');
    this.swapHands = swapHands;
    this.scale = 0.42; // size before the second hand has set one
    this.fScale = new OneEuro(1.4, 3);
    this.detections = 0;
    this.fps = 0;
    this._fpsT = 0;
    this._fpsN = 0;
    this.hold = 0.6; // seconds to keep a hand that flickered out of detection
  }

  // pinch ratio (thumb-tip <-> index-tip distance / palm length) -> 0.3x .. 3.3x.
  // Linear, fitted to the reference video: ratio ~0.12 (pinched) -> x0.3, ~1.0 (open) -> x3.3
  static ratioToScale(r) {
    return clamp(0.3 + (r - 0.12) * 3.4, 0.3, 3.3);
  }

  process(results, t) {
    this.detections++;
    this._fpsN++;
    if (t - this._fpsT >= 1) {
      this.fps = Math.round(this._fpsN / (t - this._fpsT));
      this._fpsT = t;
      this._fpsN = 0;
    }

    const L = results.multiHandLandmarks || [];
    const W = results.multiHandWorldLandmarks || [];
    const Hd = results.multiHandedness || [];
    let hands = [];
    for (let i = 0; i < L.length; i++) {
      if (!W[i]) continue;
      hands.push({ lm: L[i], wl: W[i], dispX: 1 - L[i][0].x, score: Hd[i] && Hd[i].score !== undefined ? Hd[i].score : 0.5 });
    }
    if (hands.length > 1) hands = dropDuplicateHands(hands);

    let domHand = null;
    let secHand = null;
    if (hands.length >= 2) {
      hands.sort((a, b) => a.dispX - b.dispX);
      const right = hands[hands.length - 1];
      const left = hands[0];
      [domHand, secHand] = this.swapHands ? [left, right] : [right, left];
    } else if (hands.length === 1) {
      const h = hands[0];
      // a lone hand keeps the role of whichever hand it is closest to (remembered for a while);
      // with no history it simply leads
      const MEM = 6;
      const dDom = t - this.dom.lastSeen < MEM ? Math.hypot(h.lm[0].x - this.dom.wrist[0], h.lm[0].y - this.dom.wrist[1]) : Infinity;
      const dSec = t - this.sec.lastSeen < MEM ? Math.hypot(h.lm[0].x - this.sec.wrist[0], h.lm[0].y - this.sec.wrist[1]) : Infinity;
      if (dSec < dDom && Number.isFinite(dSec)) secHand = h;
      else domHand = h;
    }

    if (domHand) this.dom.update(domHand, t);
    if (secHand) this.sec.update(secHand, t);
    this.dom.present = t - this.dom.lastSeen <= this.hold;
    this.sec.present = t - this.sec.lastSeen <= this.hold;
    for (const ch of [this.dom, this.sec]) {
      if (ch.present) ch._live = true;
      else if (ch._live) {
        ch.resetFilters();
        ch._live = false;
      }
    }

    if (secHand) {
      const target = Tracker.ratioToScale(this.sec.pinchRatio);
      this.scale = clamp(this.fScale.filter(target, t), 0.3, 3.3);
    }
  }

  // currently visible (not just held) hand?
  visible(ch, t) {
    return t - ch.lastSeen <= 0.08;
  }
}
