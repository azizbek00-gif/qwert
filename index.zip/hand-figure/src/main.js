import * as THREE from 'three';
import { Tracker, HAND_CONNECTIONS } from './tracker.js';
import { FigureScene } from './scene.js';

const params = new URLSearchParams(location.search);
const $ = (id) => document.getElementById(id);
const video = $('cam');
const fxCanvas = $('fx');
const skelCanvas = $('skel');
const glowA = $('glowA');
const glowB = $('glowB');
const glowACtx = glowA.getContext('2d');
const glowBCtx = glowB.getContext('2d');
const hud = $('hud');
const promptEl = $('prompt');
const skelCtx = skelCanvas.getContext('2d');

const store = {
  get(k, d) {
    try {
      const v = localStorage.getItem('hf:' + k);
      return v === null ? d : JSON.parse(v);
    } catch {
      return d;
    }
  },
  set(k, v) {
    try {
      localStorage.setItem('hf:' + k, JSON.stringify(v));
    } catch {
      /* ignore */
    }
  },
};

const settings = {
  thickness: store.get('thickness2', 6.6),
  trails: store.get('trails', true),
  skeleton: store.get('skeleton', true),
  swap: store.get('swap', false),
  glow: store.get('glow', true),
};

const tracker = new Tracker({ swapHands: settings.swap });
const fig = new FigureScene(fxCanvas, { thickness: settings.thickness, trails: settings.trails });

let W = window.innerWidth;
let H = window.innerHeight;

function resize() {
  W = window.innerWidth;
  H = window.innerHeight;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  fig.resize(W, H, dpr);
  skelCanvas.width = Math.round(W * dpr);
  skelCanvas.height = Math.round(H * dpr);
  skelCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
  for (const g of [glowA, glowB]) {
    g.width = Math.max(2, Math.round(W / 3));
    g.height = Math.max(2, Math.round(H / 3));
  }
}
window.addEventListener('resize', resize);
resize();

// normalized video coords -> screen px (video is object-fit: cover and mirrored)
function toScreen(nx, ny) {
  const vw = video.videoWidth || 1280;
  const vh = video.videoHeight || 720;
  const s = Math.max(W / vw, H / vh);
  const ox = (W - vw * s) / 2;
  const oy = (H - vh * s) / 2;
  return [W - (ox + nx * vw * s), oy + ny * vh * s];
}

// ---------------------------------------------------------------- skeleton
function drawHand(lm, color, dotColor, lineW) {
  const pts = lm.map((p) => toScreen(p.x, p.y));
  skelCtx.lineWidth = lineW;
  skelCtx.strokeStyle = color;
  skelCtx.lineCap = 'round';
  skelCtx.beginPath();
  for (const [a, b] of HAND_CONNECTIONS) {
    skelCtx.moveTo(pts[a][0], pts[a][1]);
    skelCtx.lineTo(pts[b][0], pts[b][1]);
  }
  skelCtx.stroke();
  skelCtx.fillStyle = dotColor;
  for (const [x, y] of pts) {
    skelCtx.beginPath();
    skelCtx.arc(x, y, lineW * 1.25, 0, Math.PI * 2);
    skelCtx.fill();
  }
}

// ---------------------------------------------------------------- frame tick
let lastT = performance.now() / 1000;
let hudTimer = 0;
const tmpQuat = new THREE.Quaternion();

function tick(dt, now) {
  const dom = tracker.dom;
  const sec = tracker.sec;

  // figure target above the leading hand
  let target = { visible: false, id: 0, x: W / 2, y: H / 2, quat: tmpQuat, scale: tracker.scale };
  if (forced) {
    target = forced; // debug hook: pose the figure without a hand (see __hf.force)
  } else if (dom.present && dom.lm && dom.hasQuat) {
    const [hx, hy] = toScreen(dom.anchor[0], dom.anchor[1]);
    const cx = Math.min(W * 0.94, Math.max(W * 0.06, hx));
    const cy = Math.min(H * 0.86, Math.max(H * 0.2, hy - 0.46 * H));
    target = { visible: true, id: dom.count, x: cx, y: cy, quat: dom.quat, scale: tracker.scale };
  }
  fig.update(target, dt);
  fig.render();
  if (settings.glow) {
    glowACtx.drawImage(fxCanvas, 0, 0, glowA.width, glowA.height);
    glowBCtx.drawImage(fxCanvas, 0, 0, glowB.width, glowB.height);
  }
  glowA.style.display = glowB.style.display = settings.glow ? '' : 'none';

  // skeleton overlay
  skelCtx.clearRect(0, 0, W, H);
  if (settings.skeleton) {
    if (sec.present && sec.lm) drawHand(sec.lm, 'rgba(255,135,190,.85)', 'rgba(255,160,205,.95)', 1.3);
    if (dom.present && dom.lm) drawHand(dom.lm, 'rgba(255,255,255,.88)', 'rgba(255,255,255,.95)', 1.4);
  }

  // HUD (throttled so numbers stay readable)
  hudTimer += dt;
  if (hudTimer > 0.18) {
    hudTimer = 0;
    const any = dom.present || sec.present;
    const fps = tracker.fps ? `${tracker.fps} fps` : '';
    if (!any) {
      hud.textContent = fps;
    } else {
      const d = dom.present ? dom.count : '—';
      const s = sec.present ? `масштаб ×${tracker.scale.toFixed(2)}` : 'нет';
      hud.textContent = `ведущая рука: ${d} · вторая рука: ${s} · ${fps}`;
    }
    if (ready) {
      promptEl.textContent = 'Покажите руку в кадр';
      promptEl.classList.toggle('hidden', any);
    }
  }
}

let forced = null;
let ready = false;
let manual = params.has('manual');

function loop(nowMs) {
  const now = nowMs / 1000;
  const dt = Math.min(0.05, Math.max(0.001, now - lastT));
  lastT = now;
  tick(dt, now);
  if (!manual) requestAnimationFrame(loop);
}

// ---------------------------------------------------------------- camera + model
function loadScript(src) {
  return new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = src;
    s.onload = res;
    s.onerror = () => rej(new Error('Не удалось загрузить ' + src));
    document.head.appendChild(s);
  });
}

async function startCamera() {
  const src = params.get('src');
  if (src) {
    video.removeAttribute('autoplay');
    video.src = src;
    video.loop = !manual;
    video.muted = true;
    await new Promise((res, rej) => {
      video.onloadeddata = res;
      video.onerror = () => rej(new Error('Не удалось открыть видео ' + src));
    });
    if (!manual) await video.play();
    return;
  }
  if (!navigator.mediaDevices?.getUserMedia) throw new Error('Браузер не поддерживает доступ к камере');
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: false,
    video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 60, min: 24 } },
  });
  video.srcObject = stream;
  await video.play();
}

let hands = null;
let inflight = false;

// MediaPipe sees the camera frame inside a dark margin. Hands that are partly out of the
// frame (e.g. a fist at the bottom edge) are detected much more reliably this way.
const PAD = params.has('pad') ? parseFloat(params.get('pad')) : 0.14;
const padCanvas = document.createElement('canvas');
const padCtx = padCanvas.getContext('2d', { alpha: false });

function inputFrame() {
  if (PAD <= 0) return video;
  const vw = video.videoWidth;
  const vh = video.videoHeight;
  const cw = Math.round(vw * (1 + 2 * PAD));
  const ch = Math.round(vh * (1 + 2 * PAD));
  if (padCanvas.width !== cw || padCanvas.height !== ch) {
    padCanvas.width = cw;
    padCanvas.height = ch;
  }
  padCtx.fillStyle = '#101010';
  padCtx.fillRect(0, 0, cw, ch);
  padCtx.drawImage(video, Math.round(PAD * vw), Math.round(PAD * vh), vw, vh);
  return padCanvas;
}

// padded-canvas normalized coords -> video normalized coords
function unpad(results) {
  if (PAD <= 0 || !results.multiHandLandmarks) return results;
  const k = 1 + 2 * PAD;
  for (const hand of results.multiHandLandmarks) {
    for (const p of hand) {
      p.x = p.x * k - PAD;
      p.y = p.y * k - PAD;
      p.z = p.z * k;
    }
  }
  return results;
}

async function pump() {
  if (manual) return;
  if (!inflight && video.readyState >= 2) {
    inflight = true;
    try {
      await hands.send({ image: inputFrame() });
    } catch (e) {
      console.error(e);
    }
    inflight = false;
  }
  if ('requestVideoFrameCallback' in video) video.requestVideoFrameCallback(pump);
  else requestAnimationFrame(pump);
}

async function boot() {
  try {
    promptEl.textContent = 'Запрос доступа к камере…';
    await startCamera();
    promptEl.textContent = 'Загрузка модели…';
    await loadScript('./mediapipe/hands.js');
    hands = new window.Hands({ locateFile: (f) => './mediapipe/' + f });
    hands.setOptions({
      maxNumHands: 2,
      modelComplexity: 1,
      minDetectionConfidence: params.has('det') ? parseFloat(params.get('det')) : 0.45,
      minTrackingConfidence: params.has('trk') ? parseFloat(params.get('trk')) : 0.5,
      selfieMode: false,
    });
    hands.onResults((r) => {
      const t = params.has('manual') && window.__tsOverride !== undefined ? window.__tsOverride : performance.now() / 1000;
      tracker.process(unpad(r), t);
    });
    await hands.initialize();
    ready = true;
    promptEl.textContent = 'Покажите руку в кадр';
    if (!manual) pump();
  } catch (e) {
    console.error(e);
    promptEl.textContent =
      e && e.name === 'NotAllowedError'
        ? 'Нет доступа к камере. Разрешите камеру в адресной строке и обновите страницу.'
        : 'Ошибка: ' + (e && e.message ? e.message : e);
  }
}

// ---------------------------------------------------------------- keys
window.addEventListener('keydown', (e) => {
  if (e.metaKey || e.ctrlKey || e.altKey) return;
  const k = e.key.toLowerCase();
  if (e.key === ']' || e.key === '+' || e.key === '=') {
    fig.setThickness(fig.thickness + 0.5);
    store.set('thickness2', fig.thickness);
  } else if (e.key === '[' || e.key === '-') {
    fig.setThickness(fig.thickness - 0.5);
    store.set('thickness2', fig.thickness);
  } else if (k === 't') {
    fig.trails = settings.trails = !settings.trails;
    store.set('trails', settings.trails);
  } else if (k === 's') {
    settings.skeleton = !settings.skeleton;
    store.set('skeleton', settings.skeleton);
  } else if (k === 'h') {
    tracker.swapHands = settings.swap = !settings.swap;
    store.set('swap', settings.swap);
  } else if (k === 'g') {
    settings.glow = !settings.glow;
    store.set('glow', settings.glow);
  } else if (k === 'f') {
    if (document.fullscreenElement) document.exitFullscreen();
    else document.documentElement.requestFullscreen?.();
  }
});

// ---------------------------------------------------------------- debug / test hooks
window.__hf = {
  tracker,
  fig,
  settings,
  ready: () => ready,
  // deterministic step for automated checks: seek video, run one inference, render
  async step(t, dt = 1 / 30, frames = 4) {
    window.__tsOverride = t;
    video.currentTime = t;
    await new Promise((r) => (video.onseeked = r));
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    await hands.send({ image: inputFrame() });
    for (let i = 0; i < frames; i++) tick(dt, t);
    const d = tracker.dom;
    const s = tracker.sec;
    return {
      t,
      dom: d.present ? d.count : null,
      domSeen: tracker.visible(d, t),
      sec: s.present,
      secSeen: tracker.visible(s, t),
      scale: +tracker.scale.toFixed(2),
      pinch: +s.pinchRatio.toFixed(2),
      scores: d.scores.map((v) => +v.toFixed(2)),
    };
  },
  tick,
  force: (t) => (forced = t),
};

requestAnimationFrame(loop);
boot();
