// Exact geometry for every figure. All figures are "N-gonal prisms" whose
// polygon lies in the hand's palm plane and whose axis is the palm normal:
//   0 fingers (fist) -> cylinder            (white-blue)
//   1 finger         -> line                (cyan)
//   2 fingers        -> rectangular box     (green)
//   3 fingers        -> triangular prism    (yellow)
//   4 fingers        -> cube                (orange)
//   5 fingers        -> pentagonal prism    (pink)
// Local units: 1.0 = circumradius, scaled by the renderer.

const TAU = Math.PI * 2;

function regularPolygon(n, radius, rot = Math.PI / 2) {
  const pts = [];
  for (let i = 0; i < n; i++) {
    const a = rot + (i * TAU) / n;
    pts.push([Math.cos(a) * radius, Math.sin(a) * radius]);
  }
  return pts;
}

function prism(poly, depth, { sideFaces = true } = {}) {
  const h = depth / 2;
  const n = poly.length;
  const seg = [];
  const tri = [];
  for (let i = 0; i < n; i++) {
    const [x0, y0] = poly[i];
    const [x1, y1] = poly[(i + 1) % n];
    seg.push(x0, y0, h, x1, y1, h); // front ring
    seg.push(x0, y0, -h, x1, y1, -h); // back ring
    seg.push(x0, y0, h, x0, y0, -h); // side edge
    if (sideFaces) {
      tri.push(x0, y0, h, x1, y1, h, x1, y1, -h);
      tri.push(x0, y0, h, x1, y1, -h, x0, y0, -h);
    }
  }
  for (let i = 1; i < n - 1; i++) {
    tri.push(poly[0][0], poly[0][1], h, poly[i][0], poly[i][1], h, poly[i + 1][0], poly[i + 1][1], h);
    tri.push(poly[0][0], poly[0][1], -h, poly[i][0], poly[i][1], -h, poly[i + 1][0], poly[i + 1][1], -h);
  }
  return { seg: new Float32Array(seg), tri: new Float32Array(tri) };
}

function cylinder(radius, depth, ringSegments = 72, rails = 4) {
  const h = depth / 2;
  const seg = [];
  const tri = [];
  for (let i = 0; i < ringSegments; i++) {
    const a0 = (i * TAU) / ringSegments;
    const a1 = ((i + 1) * TAU) / ringSegments;
    const x0 = Math.cos(a0) * radius, y0 = Math.sin(a0) * radius;
    const x1 = Math.cos(a1) * radius, y1 = Math.sin(a1) * radius;
    seg.push(x0, y0, h, x1, y1, h);
    seg.push(x0, y0, -h, x1, y1, -h);
    tri.push(x0, y0, h, x1, y1, h, x1, y1, -h);
    tri.push(x0, y0, h, x1, y1, -h, x0, y0, -h);
    tri.push(0, 0, h, x0, y0, h, x1, y1, h);
    tri.push(0, 0, -h, x0, y0, -h, x1, y1, -h);
  }
  for (let i = 0; i < rails; i++) {
    const a = Math.PI / 2 + (i * TAU) / rails;
    const x = Math.cos(a) * radius, y = Math.sin(a) * radius;
    seg.push(x, y, h, x, y, -h);
  }
  return { seg: new Float32Array(seg), tri: new Float32Array(tri) };
}

function line(length) {
  const h = length / 2;
  return { seg: new Float32Array([0, -h, 0, 0, h, 0]), tri: null };
}

export const FIGURES = [
  { id: 0, name: 'cylinder', color: 0xbdd6ff, fill: 0.035, build: () => cylinder(0.95, 1.35) },
  { id: 1, name: 'line', color: 0x2ef2e0, fill: 0, build: () => line(2.0) },
  {
    id: 2,
    name: 'box',
    color: 0x45ff8c,
    fill: 0.09,
    build: () => prism([[-0.38, -0.95], [0.38, -0.95], [0.38, 0.95], [-0.38, 0.95]], 0.45),
  },
  { id: 3, name: 'triangular-prism', color: 0xffd426, fill: 0.07, build: () => prism(regularPolygon(3, 1.05), 1.3) },
  {
    id: 4,
    name: 'cube',
    color: 0xff8a2b,
    fill: 0.06,
    build: () => prism([[-0.78, -0.78], [0.78, -0.78], [0.78, 0.78], [-0.78, 0.78]], 1.56),
  },
  { id: 5, name: 'pentagonal-prism', color: 0xff4fd8, fill: 0.06, build: () => prism(regularPolygon(5, 1.0), 1.3) },
];
