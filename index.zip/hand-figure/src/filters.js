// One Euro filter (Casiez et al. 2012): low jitter when the hand is still,
// low lag when the hand moves fast.
const smoothingFactor = (te, cutoff) => {
  const tau = 1 / (2 * Math.PI * cutoff);
  return 1 / (1 + tau / te);
};

export class OneEuro {
  constructor(minCutoff = 1.0, beta = 0.0, dCutoff = 1.0) {
    this.minCutoff = minCutoff;
    this.beta = beta;
    this.dCutoff = dCutoff;
    this.reset();
  }

  reset() {
    this.tPrev = null;
    this.xPrev = 0;
    this.dxPrev = 0;
  }

  filter(x, t) {
    if (this.tPrev === null) {
      this.tPrev = t;
      this.xPrev = x;
      this.dxPrev = 0;
      return x;
    }
    const te = Math.max(1e-3, t - this.tPrev);
    this.tPrev = t;
    const dx = (x - this.xPrev) / te;
    const aD = smoothingFactor(te, this.dCutoff);
    const dxHat = aD * dx + (1 - aD) * this.dxPrev;
    const cutoff = this.minCutoff + this.beta * Math.abs(dxHat);
    const a = smoothingFactor(te, cutoff);
    const xHat = a * x + (1 - a) * this.xPrev;
    this.xPrev = xHat;
    this.dxPrev = dxHat;
    return xHat;
  }
}
