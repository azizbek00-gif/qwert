import * as THREE from 'three';
import { LineSegments2 } from 'three/examples/jsm/lines/LineSegments2.js';
import { LineSegmentsGeometry } from 'three/examples/jsm/lines/LineSegmentsGeometry.js';
import { LineMaterial } from 'three/examples/jsm/lines/LineMaterial.js';
import { FIGURES } from './shapes.js';

// tube = solid saturated core + hot (almost white) centre line. The soft glow around it is a
// blurred copy of the canvas (see main.js) so it stays smooth on curved edges.
// width = thickness * k (px)
const LAYERS = [
  { k: 1.0, a: 1.0, white: 0.05, add: false },
  { k: 0.3, a: 1.0, white: 0.74, add: false },
];
const TRAIL_COUNT = 6;
const TRAIL_GAP = 0.022; // seconds between ghost samples
// edges nearer to the viewer are drawn brighter than the far ones, so the wireframe reads as a
// solid (no cube-flips); 1.0 = full brightness
const DEPTH_MIN = 0.5;
// the faint face tint is amplified by the glow passes; keep it light so the edges stay the star
const FILL_GAIN = 0.6;

const easeOutCubic = (x) => 1 - Math.pow(1 - x, 3);

export class FigureScene {
  constructor(canvas, { thickness = 6.6, trails = true } = {}) {
    this.canvas = canvas;
    this.thickness = thickness;
    this.trails = trails;
    // opaque black canvas, composited over the camera with CSS `mix-blend-mode: screen`,
    // so additive glow behaves exactly like light (no alpha-channel tricks needed)
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
    this.renderer.setClearColor(0x000000, 1);
    this.scene = new THREE.Scene();
    // narrow field of view = weak perspective, so cubes stay cubes even when scaled up 3x
    this.camera = new THREE.PerspectiveCamera(24, 1, 1, 60000);
    this.W = 1;
    this.H = 1;
    this.dpr = 1;

    this.pos = new THREE.Vector2(0, 0);
    this.quat = new THREE.Quaternion();
    this.scale = 1;
    this.havePose = false;
    this.hist = [];
    this.time = 0;
    this.activeId = -1;

    this._m = new THREE.Matrix4();
    this.figs = FIGURES.map((def) => this._buildFigure(def));
    this.resize(window.innerWidth, window.innerHeight, window.devicePixelRatio || 1);
  }

  _lineMaterial(color, opacity, additive = true, vertexColors = false) {
    const m = new LineMaterial({
      color,
      vertexColors,
      linewidth: 4,
      transparent: true,
      opacity,
      depthTest: false,
      depthWrite: false,
      blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
    });
    m.resolution.set(1, 1);
    return m;
  }

  _buildFigure(def) {
    const geo = def.build();
    const lineGeo = new LineSegmentsGeometry();
    lineGeo.setPositions(geo.seg);
    // per-vertex brightness (depth cue), refreshed every frame in update()
    const cue = new Float32Array(geo.seg.length).fill(1);
    lineGeo.setColors(cue);
    let radius = 1e-6;
    for (let i = 0; i < geo.seg.length; i += 3) radius = Math.max(radius, Math.hypot(geo.seg[i], geo.seg[i + 1], geo.seg[i + 2]));
    const base = new THREE.Color(def.color);
    // ghosts are drawn from the same positions but without the live depth cue
    const ghostGeo = new LineSegmentsGeometry();
    ghostGeo.setPositions(geo.seg);

    const root = new THREE.Group();
    root.visible = false;
    this.scene.add(root);

    const layers = LAYERS.map((L, i) => {
      const color = base.clone().lerp(new THREE.Color(0xffffff), L.white);
      const mat = this._lineMaterial(color, L.a, L.add, true);
      const mesh = new LineSegments2(lineGeo, mat);
      mesh.renderOrder = 10 + i;
      mesh.frustumCulled = false;
      root.add(mesh);
      return { mesh, mat, L };
    });

    let fill = null;
    if (geo.tri && def.fill > 0) {
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(geo.tri, 3));
      const mat = new THREE.MeshBasicMaterial({
        color: base,
        transparent: true,
        opacity: def.fill,
        side: THREE.DoubleSide,
        depthWrite: false,
        depthTest: false,
        blending: THREE.AdditiveBlending,
      });
      fill = new THREE.Mesh(g, mat);
      fill.renderOrder = 5;
      fill.frustumCulled = false;
      root.add(fill);
    }

    // motion ghosts
    const ghosts = [];
    for (let k = 0; k < TRAIL_COUNT; k++) {
      const gmat = this._lineMaterial(base.clone().lerp(new THREE.Color(0xffffff), 0.25), 0);
      const gmesh = new LineSegments2(ghostGeo, gmat);
      gmesh.visible = false;
      gmesh.frustumCulled = false;
      gmesh.renderOrder = 8;
      this.scene.add(gmesh);
      ghosts.push({ mesh: gmesh, mat: gmat });
    }

    return { def, root, layers, fill, ghosts, fade: 0, appear: 0, lineGeo, seg: geo.seg, cue, radius };
  }

  setThickness(px) {
    this.thickness = Math.min(18, Math.max(1.5, px));
    this._applyWidths();
  }

  _applyWidths() {
    for (const f of this.figs) {
      for (const { mat, L } of f.layers) mat.linewidth = this.thickness * L.k * this.dpr;
      for (const g of f.ghosts) g.mat.linewidth = this.thickness * 0.5 * this.dpr;
    }
  }

  resize(w, h, dpr) {
    this.W = w;
    this.H = h;
    this.dpr = Math.min(dpr, 2);
    this.renderer.setPixelRatio(this.dpr);
    this.renderer.setSize(w, h, false);
    const fov = this.camera.fov;
    this.camera.aspect = w / h;
    this.camera.position.set(0, 0, h / 2 / Math.tan((fov * Math.PI) / 360));
    this.camera.updateProjectionMatrix();
    for (const f of this.figs) {
      for (const { mat } of f.layers) mat.resolution.set(w * this.dpr, h * this.dpr);
      for (const g of f.ghosts) g.mat.resolution.set(w * this.dpr, h * this.dpr);
    }
    this._applyWidths();
  }

  // target: { visible, id, x, y (px, screen), quat, scale }
  update(target, dt) {
    this.time += dt;
    const k = (rate) => 1 - Math.exp(-dt * rate);

    if (target.visible) {
      const sx = target.x - this.W / 2;
      const sy = this.H / 2 - target.y;
      if (!this.havePose) {
        this.pos.set(sx, sy);
        this.quat.copy(target.quat);
        this.scale = target.scale;
        this.havePose = true;
      } else {
        this.pos.x += (sx - this.pos.x) * k(34);
        this.pos.y += (sy - this.pos.y) * k(34);
        this.quat.slerp(target.quat, k(30));
        this.scale *= Math.pow(target.scale / this.scale, k(20));
      }
      if (target.id !== this.activeId) {
        this.activeId = target.id;
        const f = this.figs[target.id];
        if (f.fade < 0.05) f.appear = 0;
      }
    }

    // pose history for ghost trails
    this.hist.push({ t: this.time, x: this.pos.x, y: this.pos.y, q: this.quat.clone(), s: this.scale });
    while (this.hist.length > 90 || (this.hist.length > 2 && this.time - this.hist[0].t > 0.5)) this.hist.shift();

    const unit = 0.24 * this.H;
    for (const f of this.figs) {
      const isActive = target.visible && f.def.id === this.activeId;
      const goal = isActive ? 1 : 0;
      f.fade += (goal - f.fade) * k(isActive ? 18 : 12);
      if (Math.abs(goal - f.fade) < 0.004) f.fade = goal;
      if (isActive) f.appear = Math.min(1, f.appear + dt / 0.28);
      const vis = f.fade > 0.01 && this.havePose;
      f.root.visible = vis;
      for (const g of f.ghosts) g.mesh.visible = false;
      if (!vis) continue;

      const pop = 0.78 + 0.22 * easeOutCubic(f.appear);
      const s = unit * this.scale * pop;
      f.root.position.set(this.pos.x, this.pos.y, 0);
      f.root.quaternion.copy(this.quat);
      f.root.scale.setScalar(s);
      for (const { mat, L } of f.layers) mat.opacity = L.a * f.fade;
      if (f.fill) f.fill.material.opacity = f.def.fill * FILL_GAIN * f.fade;
      this._applyDepthCue(f);

      if (this.trails && isActive) {
        for (let i = 0; i < TRAIL_COUNT; i++) {
          const tt = this.time - (i + 1) * TRAIL_GAP;
          let h = null;
          for (let j = this.hist.length - 1; j >= 0; j--) {
            if (this.hist[j].t <= tt) {
              h = this.hist[j];
              break;
            }
          }
          const g = f.ghosts[i];
          if (!h) continue;
          const dpos = Math.hypot(h.x - this.pos.x, h.y - this.pos.y);
          const drot = 2 * Math.acos(Math.min(1, Math.abs(h.q.dot(this.quat))));
          const dsc = Math.abs(Math.log(h.s / this.scale));
          const m = Math.min(1, dpos / (0.035 * this.H) + drot / 0.14 + dsc / 0.12);
          const a = 0.34 * m * Math.pow(1 - i / (TRAIL_COUNT + 1), 1.7) * f.fade;
          if (a < 0.01) continue;
          g.mat.opacity = a;
          g.mesh.visible = true;
          g.mesh.position.set(h.x, h.y, 0);
          g.mesh.quaternion.copy(h.q);
          g.mesh.scale.setScalar(unit * h.s * pop);
        }
      }
    }
  }

  // brightness of every segment end = how close it is to the viewer after the figure's rotation
  _applyDepthCue(f) {
    const e = this._m.makeRotationFromQuaternion(f.root.quaternion).elements;
    const zx = e[2], zy = e[6], zz = e[10]; // third row: world-z of a local point
    const seg = f.seg;
    const cue = f.cue;
    const inv = 0.5 / f.radius;
    for (let i = 0; i < seg.length; i += 3) {
      const z = (zx * seg[i] + zy * seg[i + 1] + zz * seg[i + 2]) * inv + 0.5; // 0 (far) .. 1 (near)
      const v = DEPTH_MIN + (1 - DEPTH_MIN) * Math.min(1, Math.max(0, z));
      cue[i] = cue[i + 1] = cue[i + 2] = v;
    }
    f.lineGeo.attributes.instanceColorStart.data.needsUpdate = true;
  }

  render() {
    this.renderer.render(this.scene, this.camera);
  }
}
