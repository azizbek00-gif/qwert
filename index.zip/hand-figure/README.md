# Hand Figure

Veb-kamera orqali qo'lni kuzatib, qo'l tepasida 3D neon shakl chizadigan ilova
(MediaPipe Hands + three.js). Hamma narsa lokal — internet kerak emas.

## Ishga tushirish

```bash
npm install
npm run dev          # http://localhost:5199
```

`npm install` qilmasdan ham ishlaydi — tayyor build `dist/` papkada:

```bash
python3 -m http.server 5199 --directory dist     # http://localhost:5199
```

Brauzer kameraga ruxsat so'raydi (faqat `localhost` yoki `https` da ishlaydi).

## Jestlar

| Ko'rsatilgan barmoqlar | Shakl | Rang |
|---|---|---|
| musht (0) | silindr | oq-ko'k |
| 1 | chiziq | cyan |
| 2 | to'rtburchak quti | yashil |
| 3 | uchburchak prizma | sariq |
| 4 | kub | to'q sariq |
| 5 | beshburchak prizma | pushti |

- **Ведущая рука** (ekranda o'ngdagi qo'l) — shakl turini tanlaydi, shakl qo'l tepasida turadi
  va qo'lning 3D burilishiga (qiya, aylantirish, yonga og'dirish) mos aylanadi.
- **Вторая рука** (ekranda chapdagi qo'l) — bosh va ko'rsatkich barmoq orasidagi masofa
  shakl masshtabini boshqaradi: qisilgan = ×0.3, ochilgan = ×3.3.
- Bitta qo'l ko'rinsa — u ведущая рука hisoblanadi.

## Klaviatura

| Tugma | Vazifa |
|---|---|
| `]` / `[` (yoki `+` / `-`) | chiziq qalinligini oshirish / kamaytirish |
| `T` | harakat izi (shleyf) yoqish / o'chirish |
| `S` | qo'l skeletini ko'rsatish / yashirish |
| `H` | ведущая / вторая qo'llarni almashtirish (chapaqay uchun) |
| `F` | to'liq ekran |

Sozlamalar brauzerda saqlanadi.

## Tuzilishi

- `src/tracker.js` — qo'l kuzatuvi: One-Euro filtr, rotatsiyaga bog'liq bo'lmagan barmoq sanash
  (3D burchaklar + gisterezis + kadr tezligiga bog'liq bo'lmagan ≥0.1 s barqarorlik), bitta qo'lni ikki marta
  aniqlashni (ikkita ustma-ust skelet) filtrlash, qo'lning 3D burilishi, pinch → masshtab.
- `src/scene.js` — three.js: qalin chiziqlar (3 qavatli neon yorug'lik), shaffof yoqlar, harakat izi.
- `src/shapes.js` — shakllar geometriyasi (aniq ko'pburchak prizmalar).
- `src/main.js` — kamera, model, HUD, skelet, klaviatura.
- `public/mediapipe/` — MediaPipe Hands modeli va wasm (lokal).

## Sozlash

- Chiziq qalinligi: `src/main.js` → `thickness` (standart 6.6 px), yoki ishlayotganda `[` `]`.
- Yaqin qirralar yorqinroq, uzoqlari xiraroq (chuqurlik ishorasi): `src/scene.js` → `DEPTH_MIN` (1 = o'chirilgan).
- Yuzalar tusi: `src/scene.js` → `FILL_GAIN`. Perspektiva kuchi: `PerspectiveCamera(24, …)` (kichikroq = kamroq buziladi).
- Shakl o'lchami: `src/scene.js` → `const unit = 0.24 * this.H`.
- Shakl qo'ldan qancha balandda turishi: `src/main.js` → `hy - 0.46 * H`.
- Masshtab diapazoni: `src/tracker.js` → `ratioToScale` (0.3 … 3.3).
- Aniqlash sezgirligi: `src/main.js` → `minDetectionConfidence`, `minTrackingConfidence`.
